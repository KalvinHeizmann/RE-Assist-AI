
import React, { useState } from 'react';
import { useData } from '../services/context/DataContext';
import { Deal, DealStage, Agent } from '../types';
import { Plus, Tag, Calendar, MessageSquare } from 'lucide-react';

const stageColors: Record<DealStage, string> = {
  [DealStage.Active]: 'border-blue-500',
  [DealStage.Pending]: 'border-yellow-500',
  [DealStage.ConditionalOffers]: 'border-purple-500',
  [DealStage.FirmDeals]: 'border-teal-500',
  [DealStage.Closed]: 'border-green-500',
  [DealStage.PaidOut]: 'border-green-700',
};

const AgentAvatar: React.FC<{ agent: Agent }> = ({ agent }) => {
  if (agent.avatarUrl) {
    return <img src={agent.avatarUrl} alt={agent.initials} className="w-8 h-8 rounded-full border-2 border-brand-dark-lighter object-cover" />;
  }
  return (
    <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold text-gray-800 border-2 border-brand-dark-lighter ${agent.color}`}>
      {agent.initials}
    </div>
  );
};

const DealCard: React.FC<{ deal: Deal }> = ({ deal }) => (
  <div className="p-4 bg-brand-dark-lighter rounded-lg shadow-sm border border-brand-dark-lighter text-brand-light-gray flex flex-col">
    <div>
        <h4 className="font-bold text-brand-white">{deal.propertyAddress}</h4>
        <p className="text-base text-brand-white font-semibold mt-2">${deal.value.toLocaleString()}</p>
        <div className="text-xs text-brand-gray flex items-center mt-1">
          <Tag className="w-3 h-3 mr-1.5" /> Commission: ${deal.commission.toLocaleString()}
        </div>
        <div className="text-xs text-brand-gray flex items-center mt-1">
          <Calendar className="w-3 h-3 mr-1.5" /> Projected Close: {new Date(deal.projectedCloseDate + 'T00:00:00').toLocaleDateString(undefined, { year: 'numeric', month: 'short', day: 'numeric' })}
        </div>
    </div>
    {deal.notes && deal.notes.length > 0 && (
        <div className="mt-3 pt-3 border-t border-brand-dark-light">
            <p className="text-xs text-brand-gray font-semibold flex items-center"><MessageSquare className="w-3 h-3 mr-1.5" /> Latest AI Note:</p>
            <p className="text-xs text-brand-light-gray italic mt-1">"{deal.notes[deal.notes.length - 1]}"</p>
        </div>
    )}
    <div className="flex items-center justify-between mt-4 pt-3 border-t border-brand-dark-light">
        <div className="flex -space-x-2">
            {deal.agents.map(agent => <AgentAvatar key={agent.initials + deal.id} agent={agent} />)}
        </div>
    </div>
  </div>
);

const DraggableDealCard: React.FC<{ deal: Deal; onDragStart: (e: React.DragEvent<HTMLDivElement>, dealId: string) => void }> = ({ deal, onDragStart }) => (
    <div
      draggable
      onDragStart={(e) => onDragStart(e, deal.id)}
      className="cursor-grab active:cursor-grabbing mb-3"
    >
        <DealCard deal={deal} />
    </div>
);

const DealColumn: React.FC<{
  stage: DealStage;
  deals: Deal[];
  onDragOver: (e: React.DragEvent<HTMLDivElement>) => void;
  onDrop: (e: React.DragEvent<HTMLDivElement>, stage: DealStage) => void;
  onDragStart: (e: React.DragEvent<HTMLDivElement>, dealId: string) => void;
}> = ({ stage, deals, onDragOver, onDrop, onDragStart }) => {
  const totalValue = deals.reduce((sum, deal) => sum + deal.value, 0);

  return (
    <div
      onDragOver={onDragOver}
      onDrop={(e) => onDrop(e, stage)}
      className="w-[320px] lg:w-[340px] flex-shrink-0"
    >
      <div className="h-full flex flex-col bg-brand-dark-light rounded-xl">
        <div className={`flex justify-between items-center p-4 border-t-4 ${stageColors[stage]} rounded-t-xl`}>
            <div>
                <h3 className="font-bold text-md text-brand-white">{stage}</h3>
                <p className="text-sm text-brand-gray">{deals.length} deals &middot; ${totalValue.toLocaleString()}</p>
            </div>
            <button className="text-brand-gray hover:text-brand-white p-1 rounded-full bg-brand-dark-lighter hover:bg-gray-700 transition-colors">
                <Plus className="w-5 h-5" />
            </button>
        </div>
        <div className="overflow-y-auto flex-grow p-2.5">
          {deals.length > 0 ? (
            deals.map(deal => (
              <DraggableDealCard key={deal.id} deal={deal} onDragStart={onDragStart} />
            ))
          ) : (
             <div className="flex items-center justify-center h-full text-center p-4">
                <p className="text-brand-gray text-sm">No deals, <button className="text-brand-blue-light font-semibold hover:underline">add deal</button></p>
             </div>
          )}
        </div>
      </div>
    </div>
  );
};

const Deals: React.FC = () => {
  const { state, dispatch } = useData();
  const [draggedDealId, setDraggedDealId] = useState<string | null>(null);

  const handleDragStart = (e: React.DragEvent<HTMLDivElement>, dealId: string) => {
    setDraggedDealId(dealId);
    e.dataTransfer.effectAllowed = 'move';
  };

  const handleDragOver = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
  };

  const handleDrop = (e: React.DragEvent<HTMLDivElement>, newStage: DealStage) => {
    e.preventDefault();
    if (draggedDealId) {
      dispatch({ type: 'UPDATE_DEAL_STAGE', payload: { dealId: draggedDealId, newStage } });
      setDraggedDealId(null);
    }
  };

  const stages = Object.values(DealStage);

  return (
    <div className="flex flex-col h-full text-brand-light-gray">
      <div className="flex-grow flex space-x-4 overflow-x-auto pb-4 -mx-8 px-8">
        {stages.map(stage => (
          <DealColumn
            key={stage}
            stage={stage}
            deals={state.deals.filter(d => d.stage === stage)}
            onDragStart={handleDragStart}
            onDragOver={handleDragOver}
            onDrop={handleDrop}
          />
        ))}
      </div>
    </div>
  );
};

export default Deals;
