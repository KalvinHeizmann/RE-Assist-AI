
import React, { useState, useMemo } from 'react';
import { useData } from '../services/context/DataContext';
import { CalendarEvent } from '../types';
import { parseAppointmentRequest } from '../services/geminiService';
import { Calendar as CalendarIcon, Plus, Clock, Bot, Loader2 } from 'lucide-react';

const CalendarHeader: React.FC<{ date: Date; onPrevMonth: () => void; onNextMonth: () => void }> = ({ date, onPrevMonth, onNextMonth }) => (
  <div className="flex justify-between items-center mb-4">
    <button onClick={onPrevMonth} className="p-2 rounded-full hover:bg-brand-dark-lighter">&lt;</button>
    <h2 className="text-xl font-bold">{date.toLocaleString('default', { month: 'long', year: 'numeric' })}</h2>
    <button onClick={onNextMonth} className="p-2 rounded-full hover:bg-brand-dark-lighter">&gt;</button>
  </div>
);

const eventSourceColors: Record<CalendarEvent['source'], string> = {
    local: 'bg-brand-blue',
    fub: 'bg-green-500',
    gcal: 'bg-purple-500',
};

const CalendarGrid: React.FC<{ date: Date; events: CalendarEvent[] }> = ({ date, events }) => {
  const daysInMonth = new Date(date.getFullYear(), date.getMonth() + 1, 0).getDate();
  const firstDayOfMonth = new Date(date.getFullYear(), date.getMonth(), 1).getDay();
  const blanks = Array(firstDayOfMonth).fill(null);
  const days = Array.from({ length: daysInMonth }, (_, i) => i + 1);

  const eventsByDate = useMemo(() => {
    const map = new Map<string, CalendarEvent[]>();
    events.forEach(event => {
      if (!map.has(event.date)) {
        map.set(event.date, []);
      }
      map.get(event.date)!.push(event);
      map.get(event.date)!.sort((a,b) => a.time.localeCompare(b.time));
    });
    return map;
  }, [events]);

  return (
    <div className="grid grid-cols-7 gap-1">
      {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map(day => (
        <div key={day} className="text-center font-semibold text-brand-gray text-sm">{day}</div>
      ))}
      {blanks.map((_, i) => <div key={`blank-${i}`} />)}
      {days.map(day => {
        const fullDate = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
        const dayEvents = eventsByDate.get(fullDate) || [];
        return (
          <div key={day} className="h-28 bg-brand-dark-light border border-brand-dark-lighter rounded p-1 overflow-y-auto">
            <span className="font-semibold text-brand-light-gray">{day}</span>
            {dayEvents.map(event => (
              <div key={event.id} title={`${event.time} - ${event.title} (Source: ${event.source})`} className="text-xs text-white p-1 rounded mt-1 truncate flex items-center">
                <span className={`w-2 h-2 rounded-full mr-1.5 flex-shrink-0 ${eventSourceColors[event.source]}`}></span>
                <span>{event.time} {event.title}</span>
              </div>
            ))}
          </div>
        );
      })}
    </div>
  );
};


const Calendar: React.FC = () => {
  const { state, dispatch } = useData();
  const [currentDate, setCurrentDate] = useState(new Date());
  const [eventRequest, setEventRequest] = useState('');
  const [isScheduling, setIsScheduling] = useState(false);

  const displayedEvents = useMemo(() => {
    let allEvents = [...state.events];
    if (state.integrations.followUpBoss.connected) {
      allEvents = [...allEvents, ...state.fubEvents];
    }
    if (state.integrations.googleCalendar.connected) {
      allEvents = [...allEvents, ...state.gcalEvents];
    }
    return allEvents;
  }, [state.events, state.fubEvents, state.gcalEvents, state.integrations]);

  const handleAiSchedule = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!eventRequest) return;
    setIsScheduling(true);
    const parsedEvent = await parseAppointmentRequest(eventRequest);
    if(parsedEvent) {
        const newEvent: CalendarEvent = {
            id: `event-${Date.now()}`,
            ...parsedEvent,
            source: 'local',
        };
        dispatch({type: 'ADD_EVENT', payload: newEvent});
        setEventRequest('');
    } else {
        alert("Sorry, I couldn't understand that request. Please try again with a clearer date and time.");
    }
    setIsScheduling(false);
  };
  
  const goToPrevMonth = () => setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() - 1, 1));
  const goToNextMonth = () => setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 1));

  return (
    <div>
      <h1 className="text-3xl font-bold text-brand-white mb-6 flex items-center"><CalendarIcon className="mr-3 text-brand-light-gray"/> Calendar</h1>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="md:col-span-2 bg-brand-dark-light p-6 rounded-xl shadow-lg border border-brand-dark-lighter">
          <CalendarHeader date={currentDate} onPrevMonth={goToPrevMonth} onNextMonth={goToNextMonth} />
          <CalendarGrid date={currentDate} events={displayedEvents} />
        </div>
        <div className="bg-brand-dark-light p-6 rounded-xl shadow-lg border border-brand-dark-lighter">
          <h2 className="text-xl font-semibold text-brand-white mb-4 flex items-center"><Bot className="mr-2 text-brand-light-gray"/> AI Scheduler</h2>
          <p className="text-brand-gray mb-4 text-sm">Describe an event and AI will add it to your calendar. e.g., "Schedule showing for the Smiths at 555 Broad St tomorrow at 3pm".</p>
          <form onSubmit={handleAiSchedule}>
            <textarea
              value={eventRequest}
              onChange={e => setEventRequest(e.target.value)}
              placeholder="Enter event details..."
              rows={4}
              className="w-full bg-brand-dark-lighter p-3 rounded-lg border-2 border-transparent focus:border-brand-blue focus:outline-none transition-colors"
            />
            <button type="submit" disabled={isScheduling} className="w-full mt-3 bg-brand-dark-lighter text-white p-3 rounded-lg hover:bg-brand-dark-lighter/80 transition-colors flex items-center justify-center disabled:opacity-50">
              {isScheduling ? <Loader2 className="animate-spin mr-2 h-5 w-5"/> : <Plus className="mr-2 h-5 w-5"/>}
              {isScheduling ? 'Scheduling...' : 'Add to Calendar'}
            </button>
          </form>
           <div className="mt-6">
             <h3 className="font-semibold text-brand-white mb-2">Upcoming Events</h3>
             <ul className="space-y-2">
                {[...displayedEvents]
                    .filter(e => new Date(`${e.date}T${e.time}`) >= new Date())
                    .sort((a,b) => new Date(`${a.date}T${a.time}`).getTime() - new Date(`${b.date}T${b.time}`).getTime())
                    .slice(0, 5)
                    .map(event => (
                        <li key={event.id} className="flex items-start text-sm p-2 bg-brand-dark-lighter rounded">
                           <Clock className="w-4 h-4 mr-3 mt-0.5 text-brand-gray"/>
                           <div className="flex-grow">
                            <div className="flex items-center">
                                <span className={`w-2 h-2 rounded-full mr-2 flex-shrink-0 ${eventSourceColors[event.source]}`}></span>
                                <p className="font-semibold text-brand-white">{event.title}</p>
                            </div>
                            <p className="text-brand-gray ml-4">{new Date(event.date + 'T00:00:00').toLocaleDateString(undefined, {weekday: 'long', month: 'long', day: 'numeric'})} at {event.time}</p>
                           </div>
                        </li>
                ))}
             </ul>
           </div>
        </div>
      </div>
    </div>
  );
};

export default Calendar;
