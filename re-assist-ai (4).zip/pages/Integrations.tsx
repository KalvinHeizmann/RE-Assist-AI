

import React, { useState, useEffect } from 'react';
import { Settings, Mail, BarChart3, CheckCircle, XCircle, KeyRound, AtSign, ClipboardCheck, FolderKanban, Calendar as CalendarIcon } from 'lucide-react';
import { useData } from '../services/context/DataContext';

// --- Re-implemented Gmail Sign-In Component ---

const GoogleLogo = () => (
    <svg version="1.1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 48 48" className="h-7 w-7">
        <g>
            <path fill="#EA4335" d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z"></path>
            <path fill="#4285F4" d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z"></path>
            <path fill="#FBBC05" d="M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.78l7.97-6.19z"></path>
            <path fill="#34A853" d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.15 1.45-4.92 2.3-8.16 2.3-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z"></path>
            <path fill="none" d="M0 0h48v48H0z"></path>
        </g>
    </svg>
);

const GmailSignInDropdown: React.FC<{
  onSuccess: (email: string) => void;
  onClose: () => void;
}> = ({ onSuccess, onClose }) => {
  const [step, setStep] = useState<'select_account' | 'grant_permission'>('select_account');

  const user = {
    email: 'real.estate.pro@gmail.com',
    name: 'Real Estate Pro',
    avatar: 'https://i.pravatar.cc/150?u=real.estate.pro@gmail.com'
  };

  const handleSelectAccount = () => {
    setStep('grant_permission');
  };

  const handleAllow = () => {
    onSuccess(user.email);
  };

  return (
    <div className="absolute top-full right-0 mt-2 w-full max-w-md bg-white rounded-lg border border-gray-300 shadow-2xl text-gray-800 z-10 font-sans">
      <div className="flex flex-col items-center justify-center p-8 border-b border-gray-200">
         <GoogleLogo />
         <h1 className="text-2xl mt-4 font-normal text-center">
            {step === 'select_account' ? 'Choose an account' : 'RE-Assist AI wants access'}
         </h1>
         <p className="text-gray-600 mt-2 text-center text-sm">
            {step === 'select_account' ? 'to continue to RE-Assist AI' : user.email}
         </p>
      </div>
      
      {step === 'select_account' && (
        <div className="p-4">
          <div onClick={handleSelectAccount} className="flex items-center p-3 rounded-md hover:bg-gray-100 cursor-pointer">
            <img src={user.avatar} alt="User Avatar" className="w-10 h-10 rounded-full" />
            <div className="ml-4">
              <p className="font-semibold">{user.name}</p>
              <p className="text-sm text-gray-600">{user.email}</p>
            </div>
          </div>
          <div className="flex items-center p-3 mt-2 rounded-md hover:bg-gray-100 cursor-pointer">
            <div className="w-10 h-10 rounded-full bg-gray-200 flex items-center justify-center">
               <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-gray-600"><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><line x1="19" x2="19" y1="8" y2="14"/><line x1="22" x2="16" y1="11" y2="11"/></svg>
            </div>
            <p className="ml-4 font-semibold text-gray-700">Use another account</p>
          </div>
        </div>
      )}

      {step === 'grant_permission' && (
          <div className="p-8">
              <p className="text-sm text-center text-gray-600">This will allow RE-Assist AI to:</p>
              <ul className="mt-4 space-y-4">
                  <li className="flex items-start text-gray-700 text-sm">
                      <svg className="w-5 h-5 text-gray-500 mr-3 mt-0.5 flex-shrink-0" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
                      <span>Read, compose, and send your emails from Gmail</span>
                  </li>
              </ul>
              <div className="flex justify-end space-x-4 mt-8">
                  <button onClick={onClose} className="px-6 py-2 text-sm font-semibold text-blue-600 rounded-md hover:bg-blue-50">Cancel</button>
                  <button onClick={handleAllow} className="px-6 py-2 text-sm font-semibold text-white bg-blue-600 rounded-md hover:bg-blue-700">Allow</button>
              </div>
          </div>
      )}
    </div>
  );
};

// --- Main Integrations Component ---

const IntegrationCard: React.FC<{ 
  icon: React.ReactNode, 
  title: string, 
  description: string,
  children: React.ReactNode 
}> = ({ icon, title, description, children }) => (
  <div className="bg-brand-dark-light rounded-xl p-6 flex flex-col items-start border border-brand-dark-lighter">
    <div className="flex items-center mb-4">
      {icon}
      <h3 className="text-xl font-bold text-brand-white ml-3">{title}</h3>
    </div>
    <p className="text-brand-gray mb-6 flex-grow">{description}</p>
    <div className="w-full mt-auto">
        {children}
    </div>
  </div>
);

const Integrations: React.FC = () => {
  const { state, dispatch } = useData();
  const { gmail, followUpBoss, monday, googleCalendar, googleDrive } = state.integrations;

  const [showGmailAuth, setShowGmailAuth] = useState(false);
  const [isFubFormVisible, setIsFubFormVisible] = useState(false);
  const [isMondayFormVisible, setIsMondayFormVisible] = useState(false);

  const [fubApiKey, setFubApiKey] = useState('');
  const [mondayApiKey, setMondayApiKey] = useState('');

  // Close dropdown on escape key
  useEffect(() => {
    const handleEsc = (event: KeyboardEvent) => {
      if (event.key === 'Escape') {
        setShowGmailAuth(false);
      }
    };
    window.addEventListener('keydown', handleEsc);
    return () => window.removeEventListener('keydown', handleEsc);
  }, []);

  const handleGmailSuccess = (userEmail: string) => {
    dispatch({ type: 'SET_GMAIL_CONNECTION', payload: { connected: true, userEmail } });
    setShowGmailAuth(false);
  };

  const handleGmailDisconnect = () => {
    dispatch({ type: 'SET_GMAIL_CONNECTION', payload: { connected: false, userEmail: null } });
  };

  const handleFubConnect = (e: React.FormEvent) => {
    e.preventDefault();
    if(fubApiKey){
        dispatch({ type: 'SET_FUB_CONNECTION', payload: { connected: true, apiKey: fubApiKey } });
        setIsFubFormVisible(false);
    }
  };

  const handleFubDisconnect = () => {
    dispatch({ type: 'SET_FUB_CONNECTION', payload: { connected: false, apiKey: null } });
  };
  
  const handleMondayConnect = (e: React.FormEvent) => {
    e.preventDefault();
    if(mondayApiKey){
        dispatch({ type: 'SET_MONDAY_CONNECTION', payload: { connected: true, apiKey: mondayApiKey } });
        setIsMondayFormVisible(false);
        setMondayApiKey('');
    }
  };

  const handleMondayDisconnect = () => {
    dispatch({ type: 'SET_MONDAY_CONNECTION', payload: { connected: false, apiKey: null } });
  };

  const handleGcalConnect = () => {
    dispatch({ type: 'SET_GCAL_CONNECTION', payload: { connected: true } });
  };

  const handleGcalDisconnect = () => {
    dispatch({ type: 'SET_GCAL_CONNECTION', payload: { connected: false } });
  };

  const handleGdriveConnect = () => {
    dispatch({ type: 'SET_GDRIVE_CONNECTION', payload: { connected: true } });
  };

  const handleGdriveDisconnect = () => {
    dispatch({ type: 'SET_GDRIVE_CONNECTION', payload: { connected: false } });
  };


  return (
    <div>
      <h1 className="text-3xl font-bold text-brand-white mb-6 flex items-center">
        <Settings className="mr-3 text-brand-light-gray" /> Integrations
      </h1>
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
        <IntegrationCard 
          icon={<Mail className="h-8 w-8 text-brand-light-gray" />}
          title="Gmail"
          description="Connect your Gmail account to automatically sync, label, and draft replies for your real estate emails."
        >
          <div className="relative w-full min-h-[90px] flex flex-col justify-center">
            {gmail.connected ? (
              <>
                <div className="flex items-center p-3 bg-gray-200/10 rounded-lg mb-3">
                    <CheckCircle className="h-5 w-5 text-gray-300 mr-3 flex-shrink-0" />
                    <div>
                        <p className="font-semibold text-gray-300">Connected</p>
                        {gmail.userEmail && <p className="text-sm text-brand-gray truncate">{gmail.userEmail}</p>}
                    </div>
                </div>
                <button 
                    onClick={handleGmailDisconnect}
                    className="w-full bg-gray-700 text-white py-2 rounded-lg font-semibold hover:bg-gray-600 transition-colors flex items-center justify-center">
                    <XCircle className="h-5 w-5 mr-2" /> Disconnect
                </button>
              </>
            ) : (
              <button 
                onClick={() => setShowGmailAuth(true)}
                className="w-full bg-brand-dark-lighter text-white py-2 rounded-lg font-semibold hover:bg-brand-dark-lighter/80 transition-colors">
                Connect
              </button>
            )}
            {showGmailAuth && (
                <GmailSignInDropdown onSuccess={handleGmailSuccess} onClose={() => setShowGmailAuth(false)} />
            )}
          </div>
        </IntegrationCard>

        <IntegrationCard 
          icon={<BarChart3 className="h-8 w-8 text-brand-light-gray" />}
          title="Follow Up Boss"
          description="Sync deals, contacts, and calendar events with FUB to keep your pipeline up-to-date across platforms."
        >
          <div className="w-full min-h-[90px] flex flex-col justify-center">
            {followUpBoss.connected ? (
               <>
                <div className="flex items-center p-3 bg-gray-200/10 rounded-lg mb-3">
                    <CheckCircle className="h-5 w-5 text-gray-300 mr-3 flex-shrink-0" />
                    <div>
                        <p className="font-semibold text-gray-300">Connected</p>
                        <p className="text-sm text-brand-gray truncate">API Key is active</p>
                    </div>
                </div>
                <button 
                    onClick={handleFubDisconnect}
                    className="w-full bg-gray-700 text-white py-2 rounded-lg font-semibold hover:bg-gray-600 transition-colors flex items-center justify-center">
                    <XCircle className="h-5 w-5 mr-2" /> Disconnect
                </button>
              </>
            ) : !isFubFormVisible ? (
              <button 
                onClick={() => setIsFubFormVisible(true)}
                className="w-full bg-brand-dark-lighter text-white py-2 rounded-lg font-semibold hover:bg-brand-dark-lighter/80 transition-colors">
                Connect
              </button>
            ) : (
              <form onSubmit={handleFubConnect} className="space-y-3">
                 <div className="relative">
                   <KeyRound className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-brand-gray" />
                   <input type="password" placeholder="API Key" required value={fubApiKey} onChange={e => setFubApiKey(e.target.value)} className="w-full bg-brand-dark-lighter p-3 pl-10 rounded-lg border-2 border-transparent focus:border-brand-blue focus:outline-none transition-colors" />
                </div>
                <div className="flex space-x-2">
                  <button type="button" onClick={() => setIsFubFormVisible(false)} className="w-full bg-brand-dark-lighter text-white py-2 rounded-lg font-semibold hover:bg-brand-dark-lighter/70">Cancel</button>
                  <button type="submit" className="w-full bg-gray-700 text-white py-2 rounded-lg font-semibold hover:bg-gray-600">Save</button>
                </div>
              </form>
            )}
          </div>
        </IntegrationCard>

        <IntegrationCard 
          icon={<ClipboardCheck className="h-8 w-8 text-brand-light-gray" />}
          title="Monday.com"
          description="Connect your Monday.com account to sync your projects and tasks, keeping all your work organized in one place."
        >
          <div className="w-full min-h-[90px] flex flex-col justify-center">
            {monday.connected ? (
               <>
                <div className="flex items-center p-3 bg-gray-200/10 rounded-lg mb-3">
                    <CheckCircle className="h-5 w-5 text-gray-300 mr-3 flex-shrink-0" />
                    <div>
                        <p className="font-semibold text-gray-300">Connected</p>
                        <p className="text-sm text-brand-gray truncate">API Key is active</p>
                    </div>
                </div>
                <button 
                    onClick={handleMondayDisconnect}
                    className="w-full bg-gray-700 text-white py-2 rounded-lg font-semibold hover:bg-gray-600 transition-colors flex items-center justify-center">
                    <XCircle className="h-5 w-5 mr-2" /> Disconnect
                </button>
              </>
            ) : !isMondayFormVisible ? (
              <button 
                onClick={() => setIsMondayFormVisible(true)}
                className="w-full bg-brand-dark-lighter text-white py-2 rounded-lg font-semibold hover:bg-brand-dark-lighter/80 transition-colors">
                Connect
              </button>
            ) : (
              <form onSubmit={handleMondayConnect} className="space-y-3">
                 <div className="relative">
                   <KeyRound className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-brand-gray" />
                   <input type="password" placeholder="API Key" required value={mondayApiKey} onChange={e => setMondayApiKey(e.target.value)} className="w-full bg-brand-dark-lighter p-3 pl-10 rounded-lg border-2 border-transparent focus:border-brand-blue focus:outline-none transition-colors" />
                </div>
                <div className="flex space-x-2">
                  <button type="button" onClick={() => setIsMondayFormVisible(false)} className="w-full bg-brand-dark-lighter text-white py-2 rounded-lg font-semibold hover:bg-brand-dark-lighter/70">Cancel</button>
                  <button type="submit" className="w-full bg-gray-700 text-white py-2 rounded-lg font-semibold hover:bg-gray-600">Save</button>
                </div>
              </form>
            )}
          </div>
        </IntegrationCard>

        <IntegrationCard 
          icon={<CalendarIcon className="h-8 w-8 text-brand-light-gray" />}
          title="Google Calendar"
          description="Mirror your Google Calendar to see all your personal and work events in one unified view."
        >
          <div className="w-full min-h-[90px] flex flex-col justify-center">
            {googleCalendar.connected ? (
              <>
                <div className="flex items-center p-3 bg-gray-200/10 rounded-lg mb-3">
                    <CheckCircle className="h-5 w-5 text-gray-300 mr-3 flex-shrink-0" />
                    <div>
                        <p className="font-semibold text-gray-300">Connected</p>
                         <p className="text-sm text-brand-gray truncate">Calendar is synced</p>
                    </div>
                </div>
                <button 
                    onClick={handleGcalDisconnect}
                    className="w-full bg-gray-700 text-white py-2 rounded-lg font-semibold hover:bg-gray-600 transition-colors flex items-center justify-center">
                    <XCircle className="h-5 w-5 mr-2" /> Disconnect
                </button>
              </>
            ) : (
              <button 
                onClick={handleGcalConnect}
                className="w-full bg-brand-dark-lighter text-white py-2 rounded-lg font-semibold hover:bg-brand-dark-lighter/80 transition-colors">
                Connect
              </button>
            )}
          </div>
        </IntegrationCard>

        <IntegrationCard 
          icon={<FolderKanban className="h-8 w-8 text-brand-light-gray" />}
          title="Google Drive"
          description="Sync Google Docs, Sheets, and Drive to access, create, and manage your important business documents."
        >
          <div className="w-full min-h-[90px] flex flex-col justify-center">
            {googleDrive.connected ? (
              <>
                <div className="flex items-center p-3 bg-gray-200/10 rounded-lg mb-3">
                    <CheckCircle className="h-5 w-5 text-gray-300 mr-3 flex-shrink-0" />
                    <div>
                        <p className="font-semibold text-gray-300">Connected</p>
                         <p className="text-sm text-brand-gray truncate">Docs, Sheets & Drive are active</p>
                    </div>
                </div>
                <button 
                    onClick={handleGdriveDisconnect}
                    className="w-full bg-gray-700 text-white py-2 rounded-lg font-semibold hover:bg-gray-600 transition-colors flex items-center justify-center">
                    <XCircle className="h-5 w-5 mr-2" /> Disconnect
                </button>
              </>
            ) : (
              <button 
                onClick={handleGdriveConnect}
                className="w-full bg-brand-dark-lighter text-white py-2 rounded-lg font-semibold hover:bg-brand-dark-lighter/80 transition-colors">
                Connect
              </button>
            )}
          </div>
        </IntegrationCard>

      </div>
    </div>
  );
};

export default Integrations;