

import React, { useState, useEffect } from 'react';
import { useData } from '../services/context/DataContext';
import { Email as EmailType } from '../types';
import { Mail, Tag, PenSquare, Loader2, Inbox, AlertTriangle } from 'lucide-react';
import { labelEmail, draftEmailReply } from '../services/geminiService';

const EmailListItem: React.FC<{ email: EmailType; onSelect: (email: EmailType) => void; isSelected: boolean }> = ({ email, onSelect, isSelected }) => (
  <div
    onClick={() => onSelect(email)}
    className={`p-4 border-l-4 cursor-pointer transition-colors ${
      isSelected ? 'bg-brand-dark-lighter border-brand-blue' : `border-transparent hover:bg-brand-dark-lighter ${!email.read ? 'bg-brand-dark-lighter/50' : ''}`
    }`}
  >
    <div className="flex justify-between items-start">
      <p className={`font-bold ${!email.read ? 'text-brand-white' : 'text-brand-light-gray'}`}>{email.sender}</p>
      {email.label && <span className="text-xs bg-brand-dark-lighter text-brand-light-gray px-2 py-1 rounded-full">{email.label}</span>}
    </div>
    <p className={`truncate text-sm ${!email.read ? 'text-brand-light-gray' : 'text-brand-gray'}`}>{email.subject}</p>
  </div>
);

const EmailDetail: React.FC<{ email: EmailType; onUpdateLabel: (id: string, label: string) => void }> = ({ email, onUpdateLabel }) => {
  const [isLabeling, setIsLabeling] = useState(false);
  const [isDrafting, setIsDrafting] = useState(false);
  const [draft, setDraft] = useState('');

  useEffect(() => {
    // Reset draft when email changes
    setDraft('');
  }, [email]);

  const handleLabel = async () => {
    setIsLabeling(true);
    const label = await labelEmail(email.body);
    if(label !== "Error") {
        onUpdateLabel(email.id, label);
    }
    setIsLabeling(false);
  };

  const handleDraft = async () => {
    setIsDrafting(true);
    const newDraft = await draftEmailReply(email.body);
    setDraft(newDraft);
    setIsDrafting(false);
  };

  return (
    <div className="p-6 h-full flex flex-col">
      <div className="pb-4 border-b border-brand-dark-lighter">
        <h2 className="text-2xl font-bold text-brand-white">{email.subject}</h2>
        <p className="text-brand-gray">From: {email.sender}</p>
        <p className="text-sm text-brand-gray">{new Date(email.timestamp).toLocaleString()}</p>
      </div>
      <div className="py-6 text-brand-light-gray flex-grow overflow-y-auto whitespace-pre-wrap">{email.body}</div>
      <div className="pt-4 border-t border-brand-dark-lighter space-y-4">
        <div className="flex space-x-2">
            <button onClick={handleLabel} disabled={isLabeling} className="flex items-center justify-center px-4 py-2 bg-brand-dark-lighter text-brand-white rounded-lg hover:bg-brand-dark-lighter/70 transition-colors disabled:opacity-50">
                {isLabeling ? <Loader2 className="animate-spin mr-2 h-5 w-5" /> : <Tag className="mr-2 h-5 w-5" />}
                {isLabeling ? 'Labeling...' : 'AI Label'}
            </button>
            <button onClick={handleDraft} disabled={isDrafting} className="flex items-center justify-center px-4 py-2 bg-brand-dark-lighter text-white rounded-lg hover:bg-brand-dark-lighter/70 transition-colors disabled:opacity-50">
                {isDrafting ? <Loader2 className="animate-spin mr-2 h-5 w-5" /> : <PenSquare className="mr-2 h-5 w-5" />}
                {isDrafting ? 'Drafting...' : 'Draft Reply'}
            </button>
        </div>
        {draft && (
            <div className="p-4 bg-brand-dark-lighter rounded-lg">
                <h3 className="font-bold text-brand-white mb-2">Suggested Reply:</h3>
                <textarea
                    className="w-full h-40 bg-brand-dark p-2 rounded-md text-brand-light-gray"
                    value={draft}
                    onChange={(e) => setDraft(e.target.value)}
                />
            </div>
        )}
      </div>
    </div>
  );
};

const Email: React.FC = () => {
  const { state, dispatch } = useData();
  const { gmailError, gmailLoading } = state;
  const [selectedEmail, setSelectedEmail] = useState<EmailType | null>(null);
  
  useEffect(() => {
    const isSelectedEmailInList = state.emails.some(e => e.id === selectedEmail?.id);
    
    if ((!selectedEmail || !isSelectedEmailInList) && state.emails.length > 0) {
      setSelectedEmail(state.emails[0]);
    } else if (state.emails.length === 0) {
      setSelectedEmail(null);
    }
  }, [state.emails, selectedEmail]);

  const handleUpdateLabel = (emailId: string, label: string) => {
    dispatch({ type: 'SET_EMAIL_LABEL', payload: { emailId, label } });
    if(selectedEmail && selectedEmail.id === emailId) {
        setSelectedEmail({...selectedEmail, label});
    }
  };

  return (
    <div className="h-full flex flex-col">
      <h1 className="text-3xl font-bold text-brand-white mb-6 flex items-center"><Mail className="mr-3 text-brand-light-gray"/> AI Email Assistant</h1>

      {gmailError && (
        <div className="bg-red-900/50 text-red-300 p-4 rounded-lg mb-4 border border-red-700 flex items-start" role="alert">
          <AlertTriangle className="h-5 w-5 mr-3 flex-shrink-0 mt-0.5" />
          <div>
            <h3 className="font-bold">Gmail Connection Error</h3>
            <p className="text-sm">{gmailError}</p>
          </div>
        </div>
      )}

      <div className="relative flex flex-grow h-[calc(100%-5rem)] bg-brand-dark-light rounded-xl shadow-lg overflow-hidden border border-brand-dark-lighter">
        {gmailLoading ? (
            <div className="absolute inset-0 flex flex-col items-center justify-center bg-brand-dark-light/80 z-10">
                <Loader2 className="h-12 w-12 animate-spin text-brand-blue-light" />
                <p className="mt-4 text-lg font-semibold text-brand-white">Connecting to Gmail...</p>
            </div>
        ) : (
            <>
                <div className="w-1/3 border-r border-brand-dark-lighter overflow-y-auto">
                {state.emails.map(email => (
                    <EmailListItem key={email.id} email={email} onSelect={setSelectedEmail} isSelected={selectedEmail?.id === email.id} />
                ))}
                </div>
                <div className="w-2/3 overflow-y-auto">
                {selectedEmail ? (
                    <EmailDetail email={selectedEmail} onUpdateLabel={handleUpdateLabel} />
                ) : (
                    <div className="flex flex-col items-center justify-center h-full text-brand-gray">
                    <Inbox className="h-24 w-24 mb-4" />
                    <h2 className="text-xl font-semibold">Select an email to view</h2>
                    <p>Your inbox is empty or no email is selected.</p>
                    </div>
                )}
                </div>
            </>
        )}
      </div>
    </div>
  );
};

export default Email;