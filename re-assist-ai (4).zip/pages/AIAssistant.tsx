import React, { useState } from 'react';
import { useData } from '../services/context/DataContext';
import { performComplexTask, ParsedTaskResult } from '../services/geminiService';
import { Bot, Loader2, Send, Sparkles } from 'lucide-react';
import { Task, CalendarEvent } from '../types';

const AIAssistant: React.FC = () => {
  const { state, dispatch } = useData();
  const [taskInstruction, setTaskInstruction] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [taskResult, setTaskResult] = useState('');
  const [isProactiveAgentEnabled, setIsProactiveAgentEnabled] = useState(false);

  const handleRunTask = async () => {
    if (!taskInstruction.trim() || isLoading) return;
    setIsLoading(true);
    setTaskResult('');

    const result = await performComplexTask(taskInstruction, state.emails, state.deals, state.integrations);
    
    if (result) {
      setTaskResult(result.summary);
      result.actions.forEach(action => {
        switch (action.type) {
          case 'SCHEDULE_EVENT':
            if (action.payload.title && action.payload.date && action.payload.time) {
                dispatch({
                    type: 'ADD_EVENT',
                    payload: {
                        id: `event-${Date.now()}-${Math.random()}`,
                        ...(action.payload as Omit<CalendarEvent, 'id' | 'source'>),
                        source: 'local'
                    }
                });
            }
            break;
          case 'CREATE_TASK':
            if (action.payload.title && action.payload.dueDate) {
                dispatch({
                    type: 'ADD_TASK',
                    payload: { 
                        id: `task-${Date.now()}-${Math.random()}`,
                        completed: false,
                        ...(action.payload as Omit<Task, 'id' | 'completed'>)
                    }
                });
            }
            break;
          case 'UPDATE_FUB_DEAL':
            const dealToUpdate = state.deals.find(d => d.propertyAddress === action.payload.propertyAddress);
            if (dealToUpdate && action.payload.note) {
                dispatch({
                    type: 'UPDATE_DEAL_NOTE',
                    payload: { dealId: dealToUpdate.id, note: action.payload.note }
                });
            }
            break;
        }
      });
    } else {
      setTaskResult("Sorry, I couldn't process that request. Please try rephrasing it.");
    }

    setIsLoading(false);
    setTaskInstruction('');
  };

  return (
    <div>
      <h1 className="text-3xl font-bold text-brand-white mb-6 flex items-center">
        <Bot className="mr-3 text-brand-light-gray"/> AI Assistant
      </h1>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        <div className="bg-brand-dark-light rounded-xl shadow-lg p-6 flex flex-col border border-brand-dark-lighter">
          <h2 className="text-xl font-semibold text-brand-white mb-4 flex items-center">
            <Send className="mr-2 text-brand-light-gray"/> One-Time Task
          </h2>
          <p className="text-brand-gray mb-4 text-sm">Give the assistant a specific task to complete now. If integrations are on, it can see your deals.</p>
          <textarea
            value={taskInstruction}
            onChange={e => setTaskInstruction(e.target.value)}
            placeholder="e.g., An offer came in for 123 Active Lane. Add a note to the deal."
            rows={4}
            className="w-full bg-brand-dark-lighter p-3 rounded-lg border-2 border-transparent focus:border-brand-blue focus:outline-none transition-colors"
          />
          <button 
            onClick={handleRunTask} 
            disabled={isLoading || !taskInstruction.trim()}
            className="w-full mt-3 bg-brand-dark-lighter text-white p-3 rounded-lg hover:bg-brand-dark-lighter/80 transition-colors flex items-center justify-center disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {isLoading ? <Loader2 className="animate-spin mr-2 h-5 w-5"/> : <Send className="mr-2 h-5 w-5"/>}
            {isLoading ? 'Processing...' : 'Run Task'}
          </button>
          
          {taskResult && (
            <div className="mt-6 p-4 bg-brand-dark-lighter/50 rounded-lg border border-brand-dark-lighter">
                <h3 className="font-bold text-brand-white mb-2">Assistant's Report:</h3>
                <p className="text-brand-light-gray whitespace-pre-wrap">{taskResult}</p>
            </div>
          )}
        </div>
        
        <div className="bg-brand-dark-light rounded-xl shadow-lg p-6 border border-brand-dark-lighter">
          <h2 className="text-xl font-semibold text-brand-white mb-4 flex items-center">
            <Sparkles className="mr-2 text-brand-light-gray"/> Proactive Agent Settings
          </h2>
          <div className="p-4 bg-brand-dark-lighter rounded-lg">
            <div className="flex items-center justify-between">
              <div className="flex-grow pr-4">
                  <h4 className="font-bold text-brand-white">Proactive Email Responder</h4>
                  <p className="text-sm text-brand-gray">Automatically draft replies for incoming emails that require a response.</p>
              </div>
              <button
                  onClick={() => setIsProactiveAgentEnabled(!isProactiveAgentEnabled)}
                  className={`relative inline-flex items-center h-6 rounded-full w-11 transition-colors focus:outline-none focus:ring-2 focus:ring-brand-blue focus:ring-offset-2 focus:ring-offset-brand-dark-lighter ${
                      isProactiveAgentEnabled ? 'bg-brand-blue' : 'bg-brand-dark-lighter'
                  }`}
                  aria-label="Toggle proactive email responder"
              >
                  <span
                      className={`inline-block w-4 h-4 transform bg-white rounded-full transition-transform ${
                          isProactiveAgentEnabled ? 'translate-x-6' : 'translate-x-1'
                      }`}
                  />
              </button>
            </div>
            <p className="text-sm mt-3 font-semibold">
                Status: <span className={isProactiveAgentEnabled ? 'text-gray-300' : 'text-gray-500'}>{isProactiveAgentEnabled ? 'Active' : 'Inactive'}</span>
            </p>
          </div>
        </div>

      </div>
    </div>
  );
};

export default AIAssistant;