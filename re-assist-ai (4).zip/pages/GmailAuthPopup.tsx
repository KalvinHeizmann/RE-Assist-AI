// This component is no longer used and has been replaced by an inline dropdown component in `pages/Integrations.tsx`.
