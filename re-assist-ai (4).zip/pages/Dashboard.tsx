
import React from 'react';
import { useData } from '../services/context/DataContext';
import { Link } from 'react-router-dom';
import { Mail, CheckSquare, Columns, Calendar as CalendarIcon, ArrowRight } from 'lucide-react';
import { Task } from '../types';

const priorityStyles: Record<Task['priority'], string> = {
  High: 'bg-red-500/20 text-red-400',
  Medium: 'bg-yellow-500/20 text-yellow-400',
  Low: 'bg-green-500/20 text-green-400',
};

const Dashboard: React.FC = () => {
  const { state } = useData();

  const unreadEmails = state.emails.filter(e => !e.read).slice(0, 3);
  const pendingTasks = state.tasks.filter(t => !t.completed).sort((a,b) => (a.priority === 'High' ? -1 : 1)).slice(0, 4);
  
  const upcomingEvents = state.events
    .filter(e => {
        const eventDateTime = new Date(`${e.date}T${e.time}`);
        return eventDateTime >= new Date();
    })
    .sort((a,b) => {
        const aDateTime = new Date(`${a.date}T${a.time}`);
        const bDateTime = new Date(`${b.date}T${b.time}`);
        return aDateTime.getTime() - bDateTime.getTime();
    })
    .slice(0, 4);
    
  const dealValueByStage = state.deals.reduce((acc, deal) => {
    const stage = deal.stage;
    if (!acc[stage]) {
      acc[stage] = 0;
    }
    acc[stage] += deal.value;
    return acc;
  }, {} as Record<string, number>);

  const Card = ({ title, icon, children, linkTo }: {title: string, icon: React.ReactNode, children: React.ReactNode, linkTo?: string}) => (
    <div className="bg-brand-dark-light rounded-xl p-6 flex flex-col h-full border border-brand-dark-lighter">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-xl font-bold text-brand-white flex items-center">{icon} {title}</h2>
        {linkTo && <Link to={linkTo} className="text-sm text-brand-blue-light hover:underline flex items-center">View all <ArrowRight className="w-4 h-4 ml-1" /></Link>}
      </div>
      <div className="flex-grow space-y-3">{children}</div>
    </div>
  );

  return (
    <div>
      <h1 className="text-3xl font-bold text-brand-white mb-6">Dashboard</h1>
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">

        <Card title="Inbox" icon={<Mail className="w-5 h-5 mr-3" />} linkTo="/email">
          {unreadEmails.length > 0 ? unreadEmails.map(email => (
            <div key={email.id} className="bg-brand-dark-lighter p-3 rounded-lg">
              <p className="font-semibold text-brand-white truncate">{email.sender}</p>
              <p className="text-sm text-brand-gray truncate">{email.subject}</p>
            </div>
          )) : <p className="text-brand-gray">Inbox zero! 🎉</p>}
        </Card>

        <Card title="Pending Tasks" icon={<CheckSquare className="w-5 h-5 mr-3" />} linkTo="/tasks">
          {pendingTasks.length > 0 ? pendingTasks.map(task => (
            <div key={task.id} className="flex items-center justify-between bg-brand-dark-lighter p-3 rounded-lg">
              <p className="text-brand-white truncate">{task.title}</p>
              <span className={`text-xs font-medium px-2 py-1 rounded-full ${priorityStyles[task.priority]}`}>{task.priority}</span>
            </div>
          )) : <p className="text-brand-gray">No pending tasks. Well done!</p>}
        </Card>

        <Card title="Upcoming Events" icon={<CalendarIcon className="w-5 h-5 mr-3" />} linkTo="/calendar">
          {upcomingEvents.length > 0 ? upcomingEvents.map(event => (
            <div key={event.id} className="bg-brand-dark-lighter p-3 rounded-lg">
              <p className="font-semibold text-brand-white truncate">{event.title}</p>
              <p className="text-sm text-brand-gray">{new Date(event.date + 'T00:00:00').toLocaleDateString(undefined, { month: 'short', day: 'numeric'})} at {event.time}</p>
            </div>
          )) : <p className="text-brand-gray">No upcoming events.</p>}
        </Card>

        <Card title="Deal Pipeline Value" icon={<Columns className="w-5 h-5 mr-3" />} linkTo="/deals">
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
                {Object.entries(dealValueByStage).map(([stage, value]) => (
                    <div key={stage} className="bg-brand-dark-lighter p-4 rounded-lg">
                        <p className="text-sm text-brand-gray">{stage}</p>
                        <p className="text-lg font-bold text-brand-white">${value.toLocaleString()}</p>
                    </div>
                ))}
            </div>
        </Card>

      </div>
    </div>
  );
};

export default Dashboard;
