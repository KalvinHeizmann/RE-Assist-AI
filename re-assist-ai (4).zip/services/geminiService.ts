import type { Email, Task, Deal, IntegrationStatus } from '../types';

// The type definition for the result of the complex task parsing
export type ParsedTaskResult = {
  summary: string;
  actions: Array<{
    type: 'SCHEDULE_EVENT';
    payload: { title: string; date: string; time: string; };
  } | {
    type: 'CREATE_TASK';
    payload: { title: string; dueDate: string; priority: 'High' | 'Medium' | 'Low'; };
  } | {
    type: 'UPDATE_FUB_DEAL';
    payload: { propertyAddress: string; note: string; };
  }>;
};

// All functions now call the backend server, which securely handles the Gemini API.

export const labelEmail = async (emailBody: string): Promise<string> => {
  try {
    const response = await fetch('/api/label-email', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ emailBody }),
    });
    if (!response.ok) {
      console.error('Failed to fetch from /api/label-email', response.statusText);
      return "Error";
    }
    const data = await response.json();
    return data.label || "Error";
  } catch (error) {
    console.error("Error labeling email:", error);
    return "Error";
  }
};

export const draftEmailReply = async (emailBody: string): Promise<string> => {
  try {
    const response = await fetch('/api/draft-reply', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ emailBody }),
    });
    if (!response.ok) {
        console.error('Failed to fetch from /api/draft-reply', response.statusText);
        return "Could not generate a draft. Please try again.";
    }
    const data = await response.json();
    return data.draft || "Could not generate a draft. Please try again.";
  } catch (error) {
    console.error("Error drafting reply:", error);
    return "Could not generate a draft. Please try again.";
  }
};

export const parseAppointmentRequest = async (text: string): Promise<{ title: string; date: string; time: string } | null> => {
    try {
        const response = await fetch('/api/parse-appointment', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ text }),
        });
        if (!response.ok) {
            console.error('Failed to fetch from /api/parse-appointment', response.statusText);
            return null;
        }
        return await response.json();
    } catch (error) {
        console.error("Error parsing appointment:", error);
        return null;
    }
}

export const performComplexTask = async (instruction: string, emails: Email[], deals: Deal[], integrations: IntegrationStatus): Promise<ParsedTaskResult | null> => {
    try {
        const response = await fetch('/api/complex-task', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ instruction, emails, deals, integrations }),
        });
        if (!response.ok) {
             console.error('Failed to fetch from /api/complex-task', response.statusText);
             return null;
        }
        return await response.json();
    } catch (error) {
        console.error("Error performing complex task:", error);
        return null;
    }
}
