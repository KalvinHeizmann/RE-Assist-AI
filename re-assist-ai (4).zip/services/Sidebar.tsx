
import React, { useState } from 'react';
import { NavLink } from 'react-router-dom';
import { LayoutDashboard, Columns, CheckSquare, Calendar as CalendarIcon, Bot, Mail, Settings, RefreshCw } from 'lucide-react';
import { useData } from './context/DataContext';

const navItems = [
  { to: '/', icon: LayoutDashboard, label: 'Dashboard' },
  { to: '/assistant', icon: Bot, label: 'AI Assistant' },
  { to: '/email', icon: Mail, label: 'Email' },
  { to: '/deals', icon: Columns, label: 'Deals' },
  { to: '/tasks', icon: CheckSquare, label: 'Tasks' },
  { to: '/calendar', icon: CalendarIcon, label: 'Calendar' },
];

const Sidebar: React.FC = () => {
  const { dispatch } = useData();
  const [isRefreshing, setIsRefreshing] = useState(false);

  const handleRefresh = () => {
    if (window.confirm("Are you sure you want to recalibrate your data? This will reset all changes to their initial state.")) {
      setIsRefreshing(true);
      // Set a timeout to allow the animation to be seen before the UI re-renders
      setTimeout(() => {
        dispatch({ type: 'RESET_DATA' });
        setIsRefreshing(false);
      }, 500);
    }
  };

  return (
    <div className="w-64 bg-brand-dark-light p-4 flex flex-col border-r border-brand-dark-lighter">
      <div className="flex items-center justify-between mb-10 p-2">
        <div className="flex items-center">
            <Bot className="h-8 w-8 text-brand-light-gray" />
            <h1 className="text-xl font-bold ml-3 text-brand-white">RE-Assist AI</h1>
        </div>
        <button
          onClick={handleRefresh}
          className="text-brand-gray hover:text-brand-white p-2 rounded-full hover:bg-brand-dark-lighter transition-colors"
          title="Recalibrate Data"
          aria-label="Recalibrate and reset all application data"
        >
          <RefreshCw className={`h-5 w-5 ${isRefreshing ? 'animate-spin' : ''}`} />
        </button>
      </div>
      <nav className="flex flex-col space-y-2">
        {navItems.map(item => (
          <NavLink
            key={item.label}
            to={item.to}
            end={item.to === '/'}
            className={({ isActive }) =>
              `flex items-center p-3 rounded-lg transition-colors ${
                isActive
                  ? 'bg-brand-dark-lighter text-brand-white'
                  : 'text-brand-gray hover:bg-brand-dark-lighter hover:text-brand-white'
              }`
            }
          >
            <item.icon className="h-5 w-5 mr-4" />
            <span className="font-medium">{item.label}</span>
          </NavLink>
        ))}
      </nav>
      <div className="mt-auto">
        <NavLink
            to="/integrations"
            className={({ isActive }) =>
              `flex items-center p-3 rounded-lg transition-colors mb-4 ${
                isActive
                  ? 'bg-brand-dark-lighter text-white'
                  : 'text-brand-gray hover:bg-brand-dark-lighter hover:text-brand-white'
              }`
            }
          >
            <Settings className="h-5 w-5 mr-4" />
            <span className="font-medium">Integrations</span>
        </NavLink>
        <div className="p-4 bg-brand-dark-lighter rounded-lg text-center">
            <p className="text-sm text-brand-white font-semibold">Upgrade to Pro</p>
            <p className="text-xs text-brand-gray mt-1 mb-4">Unlock advanced AI features and integrations.</p>
            <button className="w-full bg-brand-blue hover:bg-brand-blue-light text-white font-bold py-2 px-4 rounded-lg transition-colors">
                Upgrade Now
            </button>
        </div>
      </div>
    </div>
  );
};

export default Sidebar;
