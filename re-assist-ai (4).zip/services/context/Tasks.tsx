
import React, { useState } from 'react';
import { useData } from '../context/DataContext';
import { Task } from '../../types';
import { CheckSquare, Square, Plus } from 'lucide-react';

const priorityColors = {
  High: 'bg-red-500',
  Medium: 'bg-yellow-500',
  Low: 'bg-green-500',
};

const TaskItem: React.FC<{ task: Task; onToggle: (id: string) => void }> = ({ task, onToggle }) => (
  <div className={`flex items-center p-4 bg-brand-dark-lighter rounded-lg mb-3 transition-opacity ${task.completed ? 'opacity-50' : 'opacity-100'}`}>
    <button onClick={() => onToggle(task.id)} className="mr-4">
      {task.completed ? <CheckSquare className="text-brand-blue" /> : <Square className="text-brand-gray" />}
    </button>
    <div className="flex-grow">
      <p className={`text-brand-white ${task.completed ? 'line-through' : ''}`}>{task.title}</p>
      <p className="text-sm text-brand-gray">Due: {new Date(task.dueDate + 'T00:00:00').toLocaleDateString(undefined, { year: 'numeric', month: 'short', day: 'numeric' })}</p>
    </div>
    <div className={`w-3 h-3 rounded-full ${priorityColors[task.priority]}`}></div>
  </div>
);


const Tasks: React.FC = () => {
  const { state, dispatch } = useData();
  const [newTaskTitle, setNewTaskTitle] = useState('');
  const [priority, setPriority] = useState<'High' | 'Medium' | 'Low'>('Medium');

  const handleAddTask = (e: React.FormEvent) => {
    e.preventDefault();
    if (newTaskTitle.trim() === '') return;

    const tomorrow = new Date();
    tomorrow.setDate(tomorrow.getDate() + 1);
    const year = tomorrow.getFullYear();
    const month = String(tomorrow.getMonth() + 1).padStart(2, '0');
    const day = String(tomorrow.getDate()).padStart(2, '0');
    const dueDateString = `${year}-${month}-${day}`;

    const newTask: Task = {
      id: `task-${Date.now()}`,
      title: newTaskTitle.trim(),
      dueDate: dueDateString,
      completed: false,
      priority: priority,
    };
    dispatch({ type: 'ADD_TASK', payload: newTask });
    setNewTaskTitle('');
    setPriority('Medium');
  };

  const toggleTask = (taskId: string) => {
    dispatch({ type: 'TOGGLE_TASK', payload: { taskId } });
  };

  const pendingTasks = state.tasks
    .filter(t => !t.completed)
    .sort((a, b) => new Date(a.dueDate).getTime() - new Date(b.dueDate).getTime());
  const completedTasks = state.tasks.filter(t => t.completed);

  return (
    <div>
      <h1 className="text-3xl font-bold text-brand-white mb-6 flex items-center"><CheckSquare className="mr-3 text-brand-light-gray"/> Task Manager</h1>
      
      <div className="bg-brand-dark-light p-6 rounded-xl shadow-lg border border-brand-dark-lighter">
        <form onSubmit={handleAddTask} className="flex items-center space-x-4 mb-6">
          <input
            type="text"
            value={newTaskTitle}
            onChange={(e) => setNewTaskTitle(e.target.value)}
            placeholder="Add a new task..."
            className="flex-grow bg-brand-dark-lighter p-3 rounded-lg border-2 border-transparent focus:border-brand-blue focus:outline-none transition-colors"
          />
           <select 
             value={priority} 
             onChange={(e) => setPriority(e.target.value as 'High' | 'Medium' | 'Low')} 
             className="bg-brand-dark-lighter p-3 rounded-lg border-2 border-transparent focus:border-brand-blue focus:outline-none transition-colors"
            >
                <option value="High">High</option>
                <option value="Medium">Medium</option>
                <option value="Low">Low</option>
            </select>
          <button type="submit" className="bg-brand-dark-lighter text-white p-3 rounded-lg hover:bg-brand-dark-lighter/80 transition-colors flex items-center">
            <Plus className="mr-2 h-5 w-5"/> Add Task
          </button>
        </form>

        <div>
          <h2 className="text-xl font-semibold text-brand-white mb-4">Pending Tasks</h2>
          {pendingTasks.length > 0 ? (
            pendingTasks.map(task => <TaskItem key={task.id} task={task} onToggle={toggleTask} />)
          ) : (
            <p className="text-brand-gray">No pending tasks. Great job!</p>
          )}
        </div>
        
        <div className="mt-8">
          <h2 className="text-xl font-semibold text-brand-white mb-4">Completed Tasks</h2>
           {completedTasks.length > 0 ? (
            completedTasks.map(task => <TaskItem key={task.id} task={task} onToggle={toggleTask} />)
          ) : (
            <p className="text-brand-gray">No tasks completed yet.</p>
          )}
        </div>
      </div>
    </div>
  );
};

export default Tasks;
