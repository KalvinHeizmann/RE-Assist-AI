

import React, { createContext, useReducer, useContext, ReactNode, useEffect } from 'react';
import { DataState, DataAction, Email } from '../../types';
import { MOCK_DATA } from '../../constants';

const DataContext = createContext<{ state: DataState; dispatch: React.Dispatch<DataAction> } | undefined>(undefined);

const dataReducer = (state: DataState, action: DataAction): DataState => {
  switch (action.type) {
    case 'SET_GMAIL_LOADING':
      return { ...state, gmailLoading: action.payload };
    case 'SET_EMAILS':
      return { ...state, emails: action.payload };
    case 'SET_EMAIL_LABEL':
      return {
        ...state,
        emails: state.emails.map(email =>
          email.id === action.payload.emailId ? { ...email, label: action.payload.label } : email
        ),
      };
    case 'ADD_TASK':
      return { ...state, tasks: [action.payload, ...state.tasks] };
    case 'TOGGLE_TASK':
      return {
        ...state,
        tasks: state.tasks.map(task =>
          task.id === action.payload.taskId ? { ...task, completed: !task.completed } : task
        ),
      };
    case 'UPDATE_DEAL_STAGE':
      return {
        ...state,
        deals: state.deals.map(deal =>
          deal.id === action.payload.dealId ? { ...deal, stage: action.payload.newStage } : deal
        ),
      };
    case 'ADD_EVENT':
      return { ...state, events: [...state.events, action.payload] };
    case 'SET_GMAIL_FETCH_ERROR':
        return { ...state, gmailError: action.payload };
    case 'CLEAR_GMAIL_FETCH_ERROR':
        return { ...state, gmailError: null };
    case 'SET_GMAIL_CONNECTION': {
        const isConnecting = action.payload.connected;
        const newState = {
            ...state,
            integrations: {
              ...state.integrations,
              gmail: {
                connected: action.payload.connected,
                userEmail: action.payload.userEmail,
              },
            },
            gmailError: null, // Always clear error on connection change
            gmailLoading: isConnecting, // Set loading state
        };
        if (isConnecting) {
            // Immediately clear emails to show a loading state on the Email page.
            newState.emails = [];
        } else {
            // If disconnecting, revert to mock emails.
            newState.emails = MOCK_DATA.emails;
        }
        return newState;
    }
    case 'SET_FUB_CONNECTION':
      return {
        ...state,
        integrations: {
          ...state.integrations,
          followUpBoss: {
            connected: action.payload.connected,
            apiKey: action.payload.apiKey,
          },
        },
      };
    case 'SET_MONDAY_CONNECTION':
      return {
        ...state,
        integrations: {
          ...state.integrations,
          monday: {
            connected: action.payload.connected,
            apiKey: action.payload.apiKey,
          },
        },
      };
    case 'SET_GCAL_CONNECTION':
      return {
        ...state,
        integrations: {
          ...state.integrations,
          googleCalendar: {
            connected: action.payload.connected,
          },
        },
      };
    case 'SET_GDRIVE_CONNECTION':
        return {
          ...state,
          integrations: {
            ...state.integrations,
            googleDrive: {
              connected: action.payload.connected,
            },
          },
        };
    case 'UPDATE_DEAL_NOTE':
      return {
        ...state,
        deals: state.deals.map(deal =>
          deal.id === action.payload.dealId 
            ? { ...deal, notes: [...(deal.notes || []), action.payload.note] } 
            : deal
        ),
      };
    case 'RESET_DATA':
        return MOCK_DATA;
    default:
      return state;
  }
};

const LOCAL_STORAGE_KEY = 're_assist_ai_data';

export const DataProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [state, dispatch] = useReducer(dataReducer, MOCK_DATA, (initialState) => {
    try {
      const storedData = window.localStorage.getItem(LOCAL_STORAGE_KEY);
      if (storedData) {
        const parsed = JSON.parse(storedData);
        // Merge stored data with initial data to prevent crashes on data structure changes.
        const mergedIntegrations = { ...initialState.integrations, ...parsed.integrations };
        return { ...initialState, ...parsed, integrations: mergedIntegrations, gmailError: null, gmailLoading: false }; // Ensure loading/error state is reset
      }
    } catch (error) {
      console.error("Error parsing data from localStorage", error);
    }
    return initialState;
  });

  useEffect(() => {
    try {
      window.localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(state));
    } catch (error) {
      console.error("Error saving data to localStorage", error);
    }
  }, [state]);

  useEffect(() => {
    const fetchEmails = async () => {
      if (state.integrations.gmail.connected) {
        try {
          const response = await fetch('/api/gmail/emails');
          if (response.ok) {
            const emails: Email[] = await response.json();
            dispatch({ type: 'SET_EMAILS', payload: emails });
            dispatch({ type: 'CLEAR_GMAIL_FETCH_ERROR' });
          } else {
            console.error('Failed to fetch emails from server.');
            dispatch({ type: 'SET_GMAIL_FETCH_ERROR', payload: 'The server failed to retrieve new emails. Please try reconnecting.' });
          }
        } catch (error) {
          console.error('Error fetching emails:', error);
           dispatch({ type: 'SET_GMAIL_FETCH_ERROR', payload: 'Could not connect to the email server. Please check your connection and try again.' });
        } finally {
            dispatch({ type: 'SET_GMAIL_LOADING', payload: false });
        }
      }
    };

    if(state.integrations.gmail.connected && state.gmailLoading) {
      fetchEmails();
    }
  }, [state.integrations.gmail.connected, state.gmailLoading]);


  return (
    <DataContext.Provider value={{ state, dispatch }}>
      {children}
    </DataContext.Provider>
  );
};

export const useData = () => {
  const context = useContext(DataContext);
  if (context === undefined) {
    throw new Error('useData must be used within a DataProvider');
  }
  return context;
};